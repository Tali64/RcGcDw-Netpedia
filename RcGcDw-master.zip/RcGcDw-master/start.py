import src.rcgcdw, sys

if __name__ != "__main__":  # return if called as a module
	sys.exit(1)
