Welcome!    
If you got here, it means you want to learn how to contribute to my little project. That's great! Thank you for your interest.    

## Code ##
This may be a bit painful, the quality of code can be very... Questionable, to say the least. However, if you like adventures, you are free to contribute to the project!    
If you contribute, I ask of you to create merge requests based on testing branch. These can be merge requests for specific issues, but please use the testing branch as the base for your MR and a destination of your MR.

`master` - the most stable branch that has been tested for at least one day.    
`testing `- testing branch is what all of my hosted scripts run. It is used to test the code before merging it with master branch. 

## Translations ##
If you speak in other languages than English, you are more than welcome to. There are several ways you can contribute your translation, first the easiest one is to signup at [our weblate instance](https://translate.wikibot.de) and [contact me directly with request to review your account](https://minecraft.gamepedia.com/User:Frisk#Contact). You can also contact me so I send you the translation files you can fill in. If you know how .po files work, you are also free to send Merge Requests with translated files.
